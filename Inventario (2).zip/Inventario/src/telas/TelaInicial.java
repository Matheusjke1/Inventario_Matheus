package telas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Classe que representa a tela inicial com quatro botões.
 */
public class TelaInicial extends JFrame implements ActionListener {
    private JButton btnFuncionario;
    private JButton btnEquipamento;
    private JButton btnFornecedor;
    private JButton btnAtribuicao;

    /**
     * Construtor da classe TelaInicial.
     * Configura a janela principal e cria os botões.
     */
    public TelaInicial() {
        // Configurações da janela principal
        setTitle("Tela Inicial");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);

        // Criação dos botões
        btnFuncionario = new JButton("Gerenciar Funcionário");
        btnEquipamento = new JButton("Gerenciar Equipamento");
        btnFornecedor = new JButton("Gerenciar Fornecedor");
        btnAtribuicao = new JButton("Atribuição de Equipamento");

        // Configuração da fonte
        Font fonte = new Font("Arial", Font.PLAIN, 18); // Cria uma nova fonte com tamanho 18
        btnFuncionario.setFont(fonte);
        btnEquipamento.setFont(fonte);
        btnFornecedor.setFont(fonte);
        btnAtribuicao.setFont(fonte);

        // Configuração dos botões
        btnFuncionario.addActionListener(this);
        btnEquipamento.addActionListener(this);
        btnFornecedor.addActionListener(this);
        btnAtribuicao.addActionListener(this);

        // Criação do painel principal
        JPanel panel = new JPanel(new GridLayout(4, 1, 0, 10)); // Margem de 10 pixels entre os botões
        panel.add(btnFuncionario);
        panel.add(btnEquipamento);
        panel.add(btnFornecedor);
        panel.add(btnAtribuicao);

        // Adiciona o painel à janela principal
        getContentPane().add(panel, BorderLayout.CENTER);
    }

    /**
     * Método de ação que é executado quando um botão é clicado.
     * Verifica qual botão foi clicado e instancia a classe correspondente.
     *
     * @param e O evento de ação que ocorreu
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnFuncionario) {
            TelaFuncionario telaFuncionario = new TelaFuncionario();
            telaFuncionario.setVisible(true);
        } else if (e.getSource() == btnEquipamento) {
            TelaEquipamento telaEquipamento = new TelaEquipamento();
            telaEquipamento.setVisible(true);
        } else if (e.getSource() == btnFornecedor) {
            TelaFornecedor telaFornecedor = new TelaFornecedor();
            telaFornecedor.setVisible(true);
        } else if (e.getSource() == btnAtribuicao) {
            TelaAtribuicao telaAtribuicao = new TelaAtribuicao();
            telaAtribuicao.setVisible(true);
        }
    }

    /// Método principal que cria a instância da classe TelaInicial e a torna visível.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    // Define o estilo visual como "Nimbus"
                    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                        if ("Nimbus".equals(info.getName())) {
                            UIManager.setLookAndFeel(info.getClassName());
                            break;
                        }
                    }
                } catch (Exception e) {
                    // Caso não seja possível definir o estilo visual "Nimbus", será utilizado o estilo padrão do sistema
                }

                TelaInicial telaInicial = new TelaInicial();
                telaInicial.setVisible(true);
            }
        });
    }
}
