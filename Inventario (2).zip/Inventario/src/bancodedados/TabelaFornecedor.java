package bancodedados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TabelaFornecedor {

    public static void main(String[] args) {
        try {
            // Conectar ao banco de dados (substitua os valores conforme seu ambiente)
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/controle_estoque_TI", "root", "");

            // Chamar método para criar a tabela Fornecedor
            createTableFornecedor(connection);

            // Fechar conexão com o banco de dados
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTableFornecedor(Connection conn) {
        try {
            // Criar tabela Fornecedor
            String createFornecedorTable = "CREATE TABLE IF NOT EXISTS Fornecedor (" +
                    "Nome VARCHAR(255), " +
                    "ContratoAtivo ENUM('Sim', 'Não'), " +
                    "DataContratacao INT, " +
                    "CNPJ VARCHAR(14) PRIMARY KEY " +
                    ")";
            Statement statement = conn.createStatement();
            statement.execute(createFornecedorTable);
            System.out.println("Tabela Fornecedor criada com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
