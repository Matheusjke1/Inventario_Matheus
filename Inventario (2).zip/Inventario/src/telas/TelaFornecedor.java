package telas;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TelaFornecedor extends JFrame {

    private Connection connection;
    private JTextField textFieldNome;
    private JComboBox<String> comboBoxContrato;
    private JTextField textFieldDataContratacao;
    private JTextField textFieldCNPJ;
    private JTextArea textAreaResultados;

    public TelaFornecedor() {
        setTitle("Gerenciamento de Fornecedores");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Adicionar margem em torno do conteúdo
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        getContentPane().add(panelPrincipal);
        panelPrincipal.setLayout(new BorderLayout());

        JPanel panelFormulario = criarPanelFormulario();
        JPanel panelBotoes = criarPanelBotoes();
        JPanel panelResultados = criarPanelResultados();

        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);
        panelPrincipal.add(panelBotoes, BorderLayout.CENTER);
        panelPrincipal.add(panelResultados, BorderLayout.SOUTH);

        conectarBancoDados();
    }

    private JPanel criarPanelFormulario() {
        JPanel panelFormulario = new JPanel(new GridLayout(4, 2));

        JLabel labelNome = new JLabel("Nome:");
        textFieldNome = new JTextField();

        JLabel labelContrato = new JLabel("Contrato Ativo:");
        comboBoxContrato = new JComboBox<>(new String[]{"Sim", "Não"});

        JLabel labelDataContratacao = new JLabel("Data de Contratação:");
        textFieldDataContratacao = new JTextField();

        JLabel labelCNPJ = new JLabel("CNPJ:");
        textFieldCNPJ = new JTextField();

        panelFormulario.add(labelNome);
        panelFormulario.add(textFieldNome);
        panelFormulario.add(labelContrato);
        panelFormulario.add(comboBoxContrato);
        panelFormulario.add(labelDataContratacao);
        panelFormulario.add(textFieldDataContratacao);
        panelFormulario.add(labelCNPJ);
        panelFormulario.add(textFieldCNPJ);

        return panelFormulario;
    }

    private JPanel criarPanelBotoes() {
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton buttonInserir = new JButton("Inserir");
        buttonInserir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inserirFornecedor();
            }
        });

        JButton buttonAlterar = new JButton("Alterar");
        buttonAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alterarFornecedor();
            }
        });

        JButton buttonExcluir = new JButton("Excluir");
        buttonExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirFornecedor();
            }
        });

        JButton buttonConsultar = new JButton("Consultar");
        buttonConsultar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarFornecedor();
            }
        });

        panelBotoes.add(buttonInserir);
        panelBotoes.add(buttonAlterar);
        panelBotoes.add(buttonExcluir);
        panelBotoes.add(buttonConsultar);

        return panelBotoes;
    }

    private JPanel criarPanelResultados() {
        JPanel panelResultados = new JPanel(new BorderLayout());

        JLabel labelResultados = new JLabel("Resultados:");
        textAreaResultados = new JTextArea();
        textAreaResultados.setEditable(false);
        textAreaResultados.setRows(10); // Define o número de linhas exibidas
        JScrollPane scrollPane = new JScrollPane(textAreaResultados);

        panelResultados.add(labelResultados, BorderLayout.NORTH);
        panelResultados.add(scrollPane, BorderLayout.CENTER);

        return panelResultados;
    }

    private void conectarBancoDados() {
        try {
            // Conectar ao banco de dados
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/controle_estoque_TI", "root", "");
            System.out.println("Conexão com o banco de dados estabelecida.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void desconectarBancoDados() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Conexão com o banco de dados fechada.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão com o banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void inserirFornecedor() {
        String nome = textFieldNome.getText();
        String contrato = (String) comboBoxContrato.getSelectedItem();
        String dataContratacao = textFieldDataContratacao.getText();
        String cnpj = textFieldCNPJ.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO Fornecedor (Nome, ContratoAtivo, DataContratacao, CNPJ) VALUES (?, ?, ?, ?)"
            );
            preparedStatement.setString(1, nome);
            preparedStatement.setString(2, contrato);
            preparedStatement.setString(3, dataContratacao);
            preparedStatement.setString(4, cnpj);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Fornecedor inserido com sucesso.");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao inserir fornecedor.", "Erro", JOptionPane.ERROR_MESSAGE);
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao inserir fornecedor.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void alterarFornecedor() {
        String nome = textFieldNome.getText();
        String contrato = (String) comboBoxContrato.getSelectedItem();
        String dataContratacao = textFieldDataContratacao.getText();
        String cnpj = textFieldCNPJ.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE Fornecedor SET ContratoAtivo = ?, DataContratacao = ? WHERE Nome = ? AND CNPJ = ?"
            );
            preparedStatement.setString(1, contrato);
            preparedStatement.setString(2, dataContratacao);
            preparedStatement.setString(3, nome);
            preparedStatement.setString(4, cnpj);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Fornecedor alterado com sucesso.");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao alterar fornecedor.", "Erro", JOptionPane.ERROR_MESSAGE);
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao alterar fornecedor.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluirFornecedor() {
        String nome = textFieldNome.getText();
        String cnpj = textFieldCNPJ.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM Fornecedor WHERE Nome = ? AND CNPJ = ?"
            );
            preparedStatement.setString(1, nome);
            preparedStatement.setString(2, cnpj);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Fornecedor excluído com sucesso.");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao excluir fornecedor.", "Erro", JOptionPane.ERROR_MESSAGE);
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao excluir fornecedor.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void consultarFornecedor() {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Fornecedor");

            StringBuilder sb = new StringBuilder();
            while (resultSet.next()) {
                String nome = resultSet.getString("Nome");
                String contrato = resultSet.getString("ContratoAtivo");
                String dataContratacao = resultSet.getString("DataContratacao");
                String cnpj = resultSet.getString("CNPJ");

                sb.append("Nome: ").append(nome).append("\n");
                sb.append("Contrato Ativo: ").append(contrato).append("\n");
                sb.append("Data de Contratação: ").append(dataContratacao).append("\n");
                sb.append("CNPJ: ").append(cnpj).append("\n");
                sb.append("------------------------\n");
            }

            textAreaResultados.setText(sb.toString());

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao consultar fornecedores.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limparCampos() {
        textFieldNome.setText("");
        comboBoxContrato.setSelectedIndex(0);
        textFieldDataContratacao.setText("");
        textFieldCNPJ.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TelaFornecedor telaFornecedor = new TelaFornecedor();
                telaFornecedor.setVisible(true);
            }
        });
    }
}
