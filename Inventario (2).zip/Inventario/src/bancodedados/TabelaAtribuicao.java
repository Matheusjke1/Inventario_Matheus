package bancodedados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TabelaAtribuicao {

    public static void main(String[] args) {
        try {
            // Conectar ao banco de dados (substitua os valores conforme seu ambiente)
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/controle_estoque_TI", "root", "");

            // Chamar método para criar a tabela Equipamento
            createTableAtribuicao(connection);

            // Fechar conexão com o banco de dados
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

public static void createTableAtribuicao(Connection conn) {
    try {
        // Criar tabela TabelaAtribuicao
        String createAtribuicaoTable = "CREATE TABLE IF NOT EXISTS Atribuicao (" +
                "ID INT PRIMARY KEY AUTO_INCREMENT, " +
                "Equipamento VARCHAR(50), " +
                "Funcionario VARCHAR(50)" +
                ")";
        Statement statement = conn.createStatement();
        statement.execute(createAtribuicaoTable);
        System.out.println("Tabela Atribuicao criada com sucesso!");
    } catch (SQLException e) {
        e.printStackTrace();
    }
  }
}