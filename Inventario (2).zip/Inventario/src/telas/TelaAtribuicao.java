package telas;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TelaAtribuicao extends JFrame {

    private Connection connection;
    private JComboBox<String> comboBoxEquipamento;
    private JComboBox<String> comboBoxFuncionario;
    private JTextArea textAreaResultados;

    public TelaAtribuicao() {
        setTitle("Atribuição de Ativo a Funcionário");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Adicionar margem em torno do conteúdo
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        getContentPane().add(panelPrincipal);
        panelPrincipal.setLayout(new BorderLayout());

        JPanel panelFormulario = criarPanelFormulario();
        JPanel panelBotoes = criarPanelBotoes();
        JScrollPane scrollPaneResultados = criarScrollPaneResultados();

        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);
        panelPrincipal.add(panelBotoes, BorderLayout.CENTER);
        panelPrincipal.add(scrollPaneResultados, BorderLayout.SOUTH);

        conectarBancoDados();
        carregarEquipamentos();
        carregarFuncionarios();
    }

    private JPanel criarPanelFormulario() {
        JPanel panelFormulario = new JPanel(new GridLayout(4, 2));

        JLabel labelEquipamento = new JLabel("Equipamento:");
        comboBoxEquipamento = new JComboBox<>();

        JLabel labelFuncionario = new JLabel("Funcionário:");
        comboBoxFuncionario = new JComboBox<>();

        panelFormulario.add(labelEquipamento);
        panelFormulario.add(comboBoxEquipamento);
        panelFormulario.add(labelFuncionario);
        panelFormulario.add(comboBoxFuncionario);

        return panelFormulario;
    }

    private JPanel criarPanelBotoes() {
        JPanel panelBotoes = new JPanel();

        JButton buttonAtribuir = new JButton("Atribuir");
        buttonAtribuir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atribuirAtivo();
            }
        });

        JButton buttonConsultar = new JButton("Consultar");
        buttonConsultar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarAtribuicoes();
            }
        });

        JButton buttonExcluir = new JButton("Excluir");
        buttonExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirAtribuicao();
            }
        });

        JButton buttonAlterar = new JButton("Alterar");
        buttonAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alterarAtribuicao();
            }
        });

        panelBotoes.add(buttonAtribuir);
        panelBotoes.add(buttonConsultar);
        panelBotoes.add(buttonExcluir);
        panelBotoes.add(buttonAlterar);

        return panelBotoes;
    }

    private JScrollPane criarScrollPaneResultados() {
        textAreaResultados = new JTextArea();
        textAreaResultados.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textAreaResultados);
        scrollPane.setPreferredSize(new Dimension(380, 200));
        return scrollPane;
    }

    private void conectarBancoDados() {
        try {
            // Conectar ao banco de dados
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/controle_estoque_TI", "root", "");
            System.out.println("Conexão com o banco de dados estabelecida.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarEquipamentos() {
        try {
            // Consulta para recuperar os equipamentos disponíveis do banco de dados
            String query = "SELECT NumeroSerie FROM Equipamento";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String nomeEquipamento = resultSet.getString("NumeroSerie");
                comboBoxEquipamento.addItem(nomeEquipamento);
            }

            resultSet.close();
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao carregar equipamentos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarFuncionarios() {
        try {
            // Consulta para recuperar os funcionários do banco de dados
            String query = "SELECT Matricula FROM Funcionario";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String nomeFuncionario = resultSet.getString("Matricula");
                comboBoxFuncionario.addItem(nomeFuncionario);
            }

            resultSet.close();
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao carregar funcionários.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atribuirAtivo() {
        String equipamentoSelecionado = (String) comboBoxEquipamento.getSelectedItem();
        String funcionarioSelecionado = (String) comboBoxFuncionario.getSelectedItem();

        try {
            // Insere a atribuição do ativo no banco de dados
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Atribuicao (Equipamento, Funcionario) VALUES (?, ?)");
            statement.setString(1, equipamentoSelecionado);
            statement.setString(2, funcionarioSelecionado);
            statement.executeUpdate();
            statement.close();

            JOptionPane.showMessageDialog(null, "Ativo atribuído com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao atribuir o ativo.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void consultarAtribuicoes() {
        try {
            // Consulta para recuperar as atribuições do banco de dados
            String query = "SELECT * FROM Atribuicao";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            StringBuilder resultados = new StringBuilder();
            resultados.append("Atribuições:\n");

            while (resultSet.next()) {
                String equipamento = resultSet.getString("Equipamento");
                String funcionario = resultSet.getString("Funcionario");
                resultados.append("Equipamento: ").append(equipamento).append(", Funcionário: ").append(funcionario).append("\n");
            }

            resultSet.close();
            statement.close();

            textAreaResultados.setText(resultados.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao consultar as atribuições.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluirAtribuicao() {
        String equipamentoSelecionado = (String) comboBoxEquipamento.getSelectedItem();
        String funcionarioSelecionado = (String) comboBoxFuncionario.getSelectedItem();

        try {
            // Exclui a atribuição do ativo no banco de dados
            PreparedStatement statement = connection.prepareStatement("DELETE FROM Atribuicao WHERE Equipamento = ? AND Funcionario = ?");
            statement.setString(1, equipamentoSelecionado);
            statement.setString(2, funcionarioSelecionado);
            statement.executeUpdate();
            statement.close();

            JOptionPane.showMessageDialog(null, "Atribuição excluída com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao excluir a atribuição.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void alterarAtribuicao() {
        String equipamentoSelecionado = (String) comboBoxEquipamento.getSelectedItem();
        String funcionarioSelecionado = (String) comboBoxFuncionario.getSelectedItem();

        try {
            // Atualiza a atribuição do ativo no banco de dados
            PreparedStatement statement = connection.prepareStatement("UPDATE Atribuicao SET Funcionario = ? WHERE Equipamento = ?");
            statement.setString(1, funcionarioSelecionado);
            statement.setString(2, equipamentoSelecionado);
            statement.executeUpdate();
            statement.close();

            JOptionPane.showMessageDialog(null, "Atribuição alterada com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao alterar a atribuição.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaAtribuicao telaAtribuicao = new TelaAtribuicao();
            telaAtribuicao.setVisible(true);
        });
    }
}
