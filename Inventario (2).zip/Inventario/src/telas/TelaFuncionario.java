package telas;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Calendar;

public class TelaFuncionario extends JFrame {

    private Connection connection;
    private JTextField textFieldNome;
    private JComboBox<String> comboBoxCargo;
    private JTextField textFieldDataContratacao;
    private JTextField textFieldCPF;
    private JComboBox<String> comboBoxCentroCusto;
    private JTextArea textAreaResultados;
    private JTextField textFieldMatricula;

    public TelaFuncionario() {
        setTitle("Gerenciamento de Funcionários");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Adicionar margem em torno do conteúdo
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        getContentPane().add(panelPrincipal);
        panelPrincipal.setLayout(new BorderLayout());

        JPanel panelFormulario = criarPanelFormulario();
        JPanel panelBotoes = criarPanelBotoes();
        JPanel panelResultados = criarPanelResultados();

        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);
        panelPrincipal.add(panelBotoes, BorderLayout.CENTER);
        panelPrincipal.add(panelResultados, BorderLayout.SOUTH);

        conectarBancoDados();
    }

    private JPanel criarPanelFormulario() {
    	JPanel panelFormulario = new JPanel(new GridLayout(8, 4));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(5, 5, 5, 5);

        JLabel labelMatricula = new JLabel("Matrícula:");
        textFieldMatricula = new JTextField();
        labelMatricula.setLabelFor(textFieldMatricula);

        JLabel labelNome = new JLabel("Nome:");
        textFieldNome = new JTextField();
        labelNome.setLabelFor(textFieldNome);

        JLabel labelCargo = new JLabel("Cargo:");
        comboBoxCargo = new JComboBox<>(new String[]{"Gerente", "Supervisor", "Analista", "Assistente"});
        labelCargo.setLabelFor(comboBoxCargo);

        JLabel labelDataContratacao = new JLabel("Data de Contratação:");
        textFieldDataContratacao = new JTextField();
        labelDataContratacao.setLabelFor(textFieldDataContratacao);

        JLabel labelCPF = new JLabel("CPF:");
        textFieldCPF = new JTextField();
        labelCPF.setLabelFor(textFieldCPF);

        JLabel labelCentroCusto = new JLabel("Centro de Custo:");
        comboBoxCentroCusto = new JComboBox<>(new String[]{"QSMS", "ADM", "T.I", "JURÍDICO"});
        labelCentroCusto.setLabelFor(comboBoxCentroCusto);

        constraints.anchor = GridBagConstraints.WEST;

        constraints.gridx = 0;
        constraints.gridy = 0;
        panelFormulario.add(labelMatricula, constraints);

        constraints.gridx = 1;
        panelFormulario.add(textFieldMatricula, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        panelFormulario.add(labelNome, constraints);

        constraints.gridx = 1;
        panelFormulario.add(textFieldNome, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        panelFormulario.add(labelCargo, constraints);

        constraints.gridx = 1;
        panelFormulario.add(comboBoxCargo, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;
        panelFormulario.add(labelDataContratacao, constraints);

        constraints.gridx = 1;
        panelFormulario.add(textFieldDataContratacao, constraints);

        constraints.gridx = 0;
        constraints.gridy = 4;
        panelFormulario.add(labelCPF, constraints);

        constraints.gridx = 1;
        panelFormulario.add(textFieldCPF, constraints);

        constraints.gridx = 0;
        constraints.gridy = 5;
        panelFormulario.add(labelCentroCusto, constraints);

        constraints.gridx = 1;
        panelFormulario.add(comboBoxCentroCusto, constraints);

        return panelFormulario;
    }


    private JPanel criarPanelBotoes() {
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton buttonInserir = new JButton("Inserir");
        buttonInserir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inserirFuncionario();
            }
        });

        JButton buttonAlterar = new JButton("Alterar");
        buttonAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alterarFuncionario();
            }
        });

        JButton buttonExcluir = new JButton("Excluir");
        buttonExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirFuncionario();
            }
        });

        JButton buttonConsultar = new JButton("Consultar");
        buttonConsultar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarFuncionarios();
            }
        });

        panelBotoes.add(buttonInserir);
        panelBotoes.add(buttonAlterar);
        panelBotoes.add(buttonExcluir);
        panelBotoes.add(buttonConsultar);

        return panelBotoes;
    }

    private JPanel criarPanelResultados() {
        JPanel panelResultados = new JPanel(new BorderLayout());

        JLabel labelResultados = new JLabel("Resultados:");
        textAreaResultados = new JTextArea(10, 40);
        JScrollPane scrollPane = new JScrollPane(textAreaResultados);

        panelResultados.add(labelResultados, BorderLayout.NORTH);
        panelResultados.add(scrollPane, BorderLayout.CENTER);

        return panelResultados;
    }

    private void conectarBancoDados() {
        try {
            // Configurar a conexão com o banco de dados
            String url = "jdbc:mysql://localhost:3306/controle_estoque_TI";
            String user = "root";
            String password = "";
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void inserirFuncionario() {
    	String matricula = textFieldMatricula.getText();
        String nome = textFieldNome.getText();
        String cargo = (String) comboBoxCargo.getSelectedItem();
        String dataContratacao = textFieldDataContratacao.getText();
        String cpf = textFieldCPF.getText();
        String centroCusto = (String) comboBoxCentroCusto.getSelectedItem();

        // Lógica para inserir o funcionário no banco de dados
        try {
            // Verificar se o CPF já existe no banco de dados
            String cpfQuery = "SELECT COUNT(*) FROM funcionario WHERE cpf=?";
            PreparedStatement cpfStatement = connection.prepareStatement(cpfQuery);
            cpfStatement.setString(1, cpf);
            ResultSet cpfResult = cpfStatement.executeQuery();
            cpfResult.next();
            int cpfCount = cpfResult.getInt(1);

            if (cpfCount > 0) {
                textAreaResultados.setText("O CPF informado já existe no banco de dados.");
                return;
            }

            // Verificar se a matrícula já existe no banco de dados
            String matriculaQuery = "SELECT COUNT(*) FROM funcionario WHERE matricula=?";
            PreparedStatement matriculaStatement = connection.prepareStatement(matriculaQuery);
            matriculaStatement.setString(1, matricula);
            ResultSet matriculaResult = matriculaStatement.executeQuery();
            matriculaResult.next();
            int matriculaCount = matriculaResult.getInt(1);

            if (matriculaCount > 0) {
                textAreaResultados.setText("A matrícula gerada já existe no banco de dados. Tente novamente.");
                return;
            }

            // Inserir o funcionário no banco de dados
            String query = "INSERT INTO funcionario (matricula, nome, cargo, dataContratacao, cpf, centroCusto) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, matricula);
            preparedStatement.setString(2, nome);
            preparedStatement.setString(3, cargo);
            preparedStatement.setString(4, dataContratacao);
            preparedStatement.setString(5, cpf);
            preparedStatement.setString(6, centroCusto);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                textAreaResultados.setText("Funcionário inserido com sucesso!");
            } else {
                textAreaResultados.setText("Nenhum funcionário foi inserido.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void alterarFuncionario() {
    	
		String matricula = textFieldMatricula.getText();
        String nome = textFieldNome.getText();
        String cargo = (String) comboBoxCargo.getSelectedItem();
        String dataContratacao = textFieldDataContratacao.getText();
        String cpf = textFieldCPF.getText();
        String centroCusto = (String) comboBoxCentroCusto.getSelectedItem();

        try {
            // Verificar se a matrícula existe no banco de dados
            String matriculaQuery = "SELECT COUNT(*) FROM funcionario WHERE matricula=?";
            PreparedStatement matriculaStatement = connection.prepareStatement(matriculaQuery);
            matriculaStatement.setString(1, matricula);
            ResultSet matriculaResult = matriculaStatement.executeQuery();
            matriculaResult.next();
            int matriculaCount = matriculaResult.getInt(1);

            if (matriculaCount == 0) {
                textAreaResultados.setText("A matrícula informada não existe no banco de dados.");
                return;
            }

            // Alterar os dados do funcionário no banco de dados
            String query = "UPDATE funcionario SET nome=?, cargo=?, dataContratacao=?, cpf=?, centroCusto=? WHERE matricula=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nome);
            preparedStatement.setString(2, cargo);
            preparedStatement.setString(3, dataContratacao);
            preparedStatement.setString(4, cpf);
            preparedStatement.setString(5, centroCusto);
            preparedStatement.setString(6, matricula);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                textAreaResultados.setText("Funcionário alterado com sucesso!");
            } else {
                textAreaResultados.setText("Nenhum funcionário foi alterado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void excluirFuncionario() {
    	String matricula = textFieldMatricula.getText();

        try {
            // Verificar se a matrícula existe no banco de dados
            String matriculaQuery = "SELECT COUNT(*) FROM funcionario WHERE matricula=?";
            PreparedStatement matriculaStatement = connection.prepareStatement(matriculaQuery);
            matriculaStatement.setString(1, matricula);
            ResultSet matriculaResult = matriculaStatement.executeQuery();
            matriculaResult.next();
            int matriculaCount = matriculaResult.getInt(1);

            if (matriculaCount == 0) {
                textAreaResultados.setText("A matrícula informada não existe no banco de dados.");
                return;
            }

            // Excluir o funcionário do banco de dados
            String query = "DELETE FROM funcionario WHERE matricula=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, matricula);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                textAreaResultados.setText("Funcionário excluído com sucesso!");
            } else {
                textAreaResultados.setText("Nenhum funcionário foi excluído.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void consultarFuncionarios() {
        // Lógica para consultar os funcionários no banco de dados
    	
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM funcionario");

            StringBuilder sb = new StringBuilder();
            while (resultSet.next()) {
            	String matricula = textFieldMatricula.getText();
                String nome = resultSet.getString("nome");
                String cargo = resultSet.getString("cargo");
                String dataContratacao = resultSet.getString("dataContratacao");
                String cpf = resultSet.getString("cpf");
                String centroCusto = resultSet.getString("centroCusto");

                sb.append("Matrícula: ").append(matricula).append("\n");
                sb.append("Nome: ").append(nome).append("\n");
                sb.append("Cargo: ").append(cargo).append("\n");
                sb.append("Data de Contratação: ").append(dataContratacao).append("\n");
                sb.append("CPF: ").append(cpf).append("\n");
                sb.append("Centro de Custo: ").append(centroCusto).append("\n");
                sb.append("--------------------------\n");
            }

            textAreaResultados.setText(sb.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String gerarMatricula() {
        // Lógica para gerar uma matrícula única para cada funcionário
        // Obter o ano atual
        Calendar calendar = Calendar.getInstance();
        int ano = calendar.get(Calendar.YEAR);

        // Obter o próximo número de matrícula disponível
        int proximoNumero = obterProximoNumeroMatricula();

        // Formatar a matrícula no formato "ANO-NUMERO" (por exemplo, 2023-001)
        String matricula = String.format("%d-%03d", ano, proximoNumero);

        return matricula;
    }

    private int obterProximoNumeroMatricula() {
        int proximoNumero = 0;

        try {
            // Consultar o último número de matrícula utilizado no banco de dados
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT MAX(SUBSTRING_INDEX(matricula, '-', -1)) FROM funcionario");

            if (resultSet.next()) {
                String ultimoNumeroMatricula = resultSet.getString(1);

                if (ultimoNumeroMatricula != null) {
                    // Se existir um número de matrícula no banco de dados, incrementar em 1
                    proximoNumero = Integer.parseInt(ultimoNumeroMatricula) + 1;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return proximoNumero;
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new TelaFuncionario().setVisible(true);
            }
        });
    }
}
