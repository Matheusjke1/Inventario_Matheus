package bancodedados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TabelaEquipamento {

    public static void main(String[] args) {
        try {
            // Conectar ao banco de dados (substitua os valores conforme seu ambiente)
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/controle_estoque_TI", "root", "");

            // Chamar método para criar a tabela Equipamento
            createTableEquipamento(connection);

            // Fechar conexão com o banco de dados
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTableEquipamento(Connection conn) {
        try {
            // Criar tabela Equipamento
            String createEquipamentoTable = "CREATE TABLE IF NOT EXISTS Equipamento (" +
                    "ID INT PRIMARY KEY AUTO_INCREMENT, " +
                    "NumeroSerie VARCHAR(50), " +
                    "Tipo VARCHAR(255), " +
                    "Modelo VARCHAR(50), " +
                    "Fabricante VARCHAR(255), " +
                    "CNPJ_Fornecedor VARCHAR(14), " +
                    "FOREIGN KEY (CNPJ_Fornecedor) REFERENCES Fornecedor(CNPJ)" +
                    ")";
            Statement statement = conn.createStatement();
            statement.execute(createEquipamentoTable);
            System.out.println("Tabela Equipamento criada com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
