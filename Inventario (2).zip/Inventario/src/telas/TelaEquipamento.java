package telas;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class TelaEquipamento extends JFrame {

    private Connection connection;
    private JComboBox<String> comboBoxTipo;
    private JComboBox<String> comboBoxFornecedor;
    private JTextField textFieldModelo;
    private JTextField textFieldNumeroSerie;
    private JTextArea textAreaResultados;

    public TelaEquipamento() {
        setTitle("Gerenciamento de Equipamentos");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Adicionar margem em torno do conteúdo
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        getContentPane().add(panelPrincipal);
        panelPrincipal.setLayout(new BorderLayout());

        JPanel panelFormulario = criarPanelFormulario();
        JPanel panelBotoes = criarPanelBotoes();
        JPanel panelResultados = criarPanelResultados();

        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);
        panelPrincipal.add(panelBotoes, BorderLayout.CENTER);
        panelPrincipal.add(panelResultados, BorderLayout.SOUTH);

        conectarBancoDados();
        carregarFornecedores();
    }

    private JPanel criarPanelFormulario() {
        JPanel panelFormulario = new JPanel(new GridLayout(4, 2));

        JLabel labelTipo = new JLabel("Tipo:");
        comboBoxTipo = new JComboBox<>(new String[]{"Celular", "Monitor", "Notebook"});

        JLabel labelFornecedor = new JLabel("Fornecedor:");
        comboBoxFornecedor = new JComboBox<>();
        

        JLabel labelModelo = new JLabel("Modelo:");
        textFieldModelo = new JTextField();

        JLabel labelNumeroSerie = new JLabel("Número de Série:");
        textFieldNumeroSerie = new JTextField();

        panelFormulario.add(labelTipo);
        panelFormulario.add(comboBoxTipo);
        panelFormulario.add(labelFornecedor);
        panelFormulario.add(comboBoxFornecedor);
        panelFormulario.add(labelModelo);
        panelFormulario.add(textFieldModelo);
        panelFormulario.add(labelNumeroSerie);
        panelFormulario.add(textFieldNumeroSerie);

        return panelFormulario;
    }

    private JPanel criarPanelBotoes() {
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton buttonInserir = new JButton("Inserir");
        buttonInserir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inserirEquipamento();
            }
        });

        JButton buttonAlterar = new JButton("Alterar");
        buttonAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alterarEquipamento();
            }
        });

        JButton buttonExcluir = new JButton("Excluir");
        buttonExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirEquipamento();
            }
        });

        JButton buttonConsultar = new JButton("Consultar");
        buttonConsultar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarEquipamento();
            }
        });

        panelBotoes.add(buttonInserir);
        panelBotoes.add(buttonAlterar);
        panelBotoes.add(buttonExcluir);
        panelBotoes.add(buttonConsultar);

        return panelBotoes;
    }

    private JPanel criarPanelResultados() {
        JPanel panelResultados = new JPanel(new BorderLayout());

        JLabel labelResultados = new JLabel("Resultados:");
        textAreaResultados = new JTextArea();
        textAreaResultados.setEditable(false);
        textAreaResultados.setRows(10); // Define o número de linhas exibidas
        JScrollPane scrollPane = new JScrollPane(textAreaResultados);

        panelResultados.add(labelResultados, BorderLayout.NORTH);
        panelResultados.add(scrollPane, BorderLayout.CENTER);

        return panelResultados;
    }

    private void conectarBancoDados() {
        try {
            // Conectar ao banco de dados (substitua os valores conforme seu ambiente)
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/controle_estoque_TI", "root", "");
            System.out.println("Conexão com o banco de dados estabelecida.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarFornecedores() {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT CNPJ, Nome FROM Fornecedor");

            Map<String, String> fornecedores = new HashMap<>();
            while (resultSet.next()) {
                String cnpj = resultSet.getString("CNPJ");
                String nome = resultSet.getString("Nome");
                fornecedores.put(cnpj, nome);
                comboBoxFornecedor.addItem(cnpj);
            }

            // Armazena o mapa de fornecedores como uma propriedade da ComboBox
            comboBoxFornecedor.putClientProperty("fornecedores", fornecedores);

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao carregar fornecedores.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void inserirEquipamento() {
        String tipo = (String) comboBoxTipo.getSelectedItem();
        String fornecedor = (String) comboBoxFornecedor.getSelectedItem();
        String modelo = textFieldModelo.getText();
        String numeroSerie = textFieldNumeroSerie.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO Equipamento (Tipo, CNPJ_Fornecedor, Modelo, NumeroSerie) VALUES (?, ?, ?, ?)"
            );
            preparedStatement.setString(1, tipo);
            preparedStatement.setString(2, fornecedor);
            preparedStatement.setString(3, modelo);
            preparedStatement.setString(4, numeroSerie);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Equipamento inserido com sucesso.");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao inserir equipamento.", "Erro", JOptionPane.ERROR_MESSAGE);
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao inserir equipamento.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void alterarEquipamento() {
        String tipo = (String) comboBoxTipo.getSelectedItem();
        String fornecedor = (String) comboBoxFornecedor.getSelectedItem();
        String modelo = textFieldModelo.getText();
        String numeroSerie = textFieldNumeroSerie.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE Equipamento SET Tipo = ?, CNPJ_Fornecedor = ?, Modelo = ? WHERE NumeroSerie = ?"
            );
            preparedStatement.setString(1, tipo);
            preparedStatement.setString(2, fornecedor);
            preparedStatement.setString(3, modelo);
            preparedStatement.setString(4, numeroSerie);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Equipamento alterado com sucesso.");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao alterar equipamento.", "Erro", JOptionPane.ERROR_MESSAGE);
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao alterar equipamento.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluirEquipamento() {
        String numeroSerie = textFieldNumeroSerie.getText();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM Equipamento WHERE NumeroSerie = ?"
            );
            preparedStatement.setString(1, numeroSerie);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Equipamento excluído com sucesso.");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao excluir equipamento.", "Erro", JOptionPane.ERROR_MESSAGE);
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao excluir equipamento.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void consultarEquipamento() {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Equipamento");

            StringBuilder sb = new StringBuilder();
            while (resultSet.next()) {
                String tipo = resultSet.getString("Tipo");
                String fornecedor = resultSet.getString("CNPJ_Fornecedor");
                String modelo = resultSet.getString("Modelo");
                String numeroSerie = resultSet.getString("NumeroSerie");

                sb.append("Tipo: ").append(tipo).append(", ");
                sb.append("Fornecedor: ").append(fornecedor).append(", ");
                sb.append("Modelo: ").append(modelo).append(", ");
                sb.append("Número de Série: ").append(numeroSerie).append("\n");
            }

            textAreaResultados.setText(sb.toString());

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao consultar equipamentos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limparCampos() {
        comboBoxTipo.setSelectedIndex(0);
        comboBoxFornecedor.setSelectedIndex(0);
        textFieldModelo.setText("");
        textFieldNumeroSerie.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TelaEquipamento().setVisible(true);
            }
        });
    }
}
