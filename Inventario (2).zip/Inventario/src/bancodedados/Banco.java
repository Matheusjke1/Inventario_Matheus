package bancodedados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Banco {

    public static void main(String[] args) {
        // Configurações de conexão ao banco de dados
        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "controle_estoque_TI";
        String username = "root";
        String password = "";

        Connection conn = null;
        Statement stmt = null;

        try {
            // Conectar ao servidor do banco de dados
            conn = connectToServer(url, username, password);

            // Criar o banco de dados
            stmt = conn.createStatement();
            String createDBSql = "CREATE DATABASE IF NOT EXISTS " + dbName;
            stmt.executeUpdate(createDBSql);
            System.out.println("Banco de dados criado com sucesso!");

            // Conectar ao banco de dados criado
            String dbUrl = url + dbName;
            conn = connectToServer(dbUrl, username, password);

            // Chamar o método para criar a tabela Fornecedor
            TabelaFornecedor.createTableFornecedor(conn);
            
            // Chamar o método para criar a tabela Funcionário
            TabelaFuncionario.createTableFuncionario(conn);
            
            // Chamar o método para criar a tabela Equipamento
            TabelaEquipamento.createTableEquipamento(conn);
            
            // Chamar o método para criar a tabela Atribuicao
            TabelaAtribuicao.createTableAtribuicao(conn);
            

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                // Fechar as conexões
                if (stmt != null)
                    stmt.close();
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static Connection connectToServer(String url, String username, String password) throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }
}
