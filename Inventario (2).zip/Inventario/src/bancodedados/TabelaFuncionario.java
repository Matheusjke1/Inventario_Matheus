package bancodedados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TabelaFuncionario {

    public static void main(String[] args) {
        try {
            // Conectar ao banco de dados (substitua os valores conforme seu ambiente)
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/controle_estoque_TI", "root", "");

            // Chamar método para criar tabela
            createTableFuncionario(connection);

            // Fechar conexão com o banco de dados
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTableFuncionario(Connection conn) {
        try {
            // Criar tabela Funcionário
        	String createFuncionarioTable = "CREATE TABLE Funcionario (" +
        	        "Nome VARCHAR(50), " +
        	        "CPF VARCHAR(14), " +
        	        "Matricula INT, " +
        	        "CentroCusto VARCHAR(50), " +
        	        "Cargo VARCHAR(50)," +
        	        "DataContratacao INT, " +
        	        "PRIMARY KEY (Matricula, CPF)," +
        	        "UNIQUE (CPF)" +
        	        ")";

            Statement statement = conn.createStatement();
            statement.execute(createFuncionarioTable);
            System.out.println("Tabela Funcionário criada com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
